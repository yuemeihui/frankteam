<?php
require_once "WxPay.Api.php";
require_once 'WxPay.Notify.php';
require_once 'log.php';
?>