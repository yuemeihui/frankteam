<?php

/**
 * 
 * 接口访问类，包含所有微信支付API列表的封装，类中方法为static方法，
 * 每个接口有默认超时时间（除提交被扫支付为10s，上报超时时间为1s外，其他均为6s）
 * @author
 *
 */

class Wxapi
{
	public function curl_post($data,$url){
       $data = json_encode($data,JSON_UNESCAPED_UNICODE);
        $ch = curl_init ();
        curl_setopt ( $ch, CURLOPT_URL,$url);
        curl_setopt ( $ch, CURLOPT_POST, 1 );
        curl_setopt ( $ch, CURLOPT_HEADER, 0 );
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, 1 );
        curl_setopt ( $ch, CURLOPT_POSTFIELDS, $data);
        $return = curl_exec ($ch);
        curl_close ($ch);
        return $return;
    }

    /**
     * 
     */
    public function curl_get($uri){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $uri);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE); 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $output = curl_exec($ch);
        curl_close($ch);
        return $output;
    }
	/**
	 * 
	 * //获取access_token
	 * @param $appid   //第三方用户唯一凭证
	 * @param int $secret //第三方用户唯一凭证密钥，即appsecret
	 * @return 成功时返回，其他抛异常（参数错误）
	 */
	public function get_access_token($appid, $secret)
	{
		$uri = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=".$appid."&secret=".$secret;
		$result = $this->curl_get($uri);
		$result = json_decode($result,true);
		return $result;
	}
	/**  //获取服务器ip
	 * @param $access_token   //公众号的access_token
	 * @return 成功时返回，其他抛异常（参数错误）
	 */
	public function get_server_ip($access_token)
	{
		$uri = "https://api.weixin.qq.com/cgi-bin/getcallbackip?access_token=".$access_token;
		$result = $this->curl_get($uri);
		$result = json_decode($result,true);
		return $result;
	}
	//获取用户openid
		/**  //获取服务器ip
	 * @param $appid   //公众号的appid
	 * @param $secret   //公众号的secret
	 * @param $code   //从授权链接获取的code
	 * @return 成功时返回，其他抛异常（参数错误）
	 */
	public function get_openid($appid,$secret,$code){
		$uri = "https://api.weixin.qq.com/sns/oauth2/access_token?appid={$appid}&secret={$secret}&code={$code}&grant_type=authorization_code";
        $res = $this->curl_get($uri);
        $res = json_decode($res,true);
        return $res;
	}
	//获取用户信息
		/**  //获取服务器ip
	 * @param $access_token   //公众号的access_token
	 * @return 成功时返回，其他抛异常（参数错误）
	 */
	public function get_userinfo($access_token,$openid)
	{
		$uri = "https://api.weixin.qq.com/cgi-bin/user/info?access_token={$access_token}&openid={$openid}&lang=zh_CN";
		$result = $this->curl_get($uri);
		$result = json_decode($result,true);
		return $result;
	}

	
	//审核用户（一般出现在构造里）
		/**  //获取服务器ip
	 * @param $appid   //公众号的appid
	 * @param $secret   //公众号的secret
	 * @param $access_token   //access_token
	 * @return 成功时返回，其他抛异常（参数错误）
	 */
	public function checkUser($appid,$secret,$access_token){
        $code = I("get.code");
        
        if(!$code){
            $uri = getServerUri();
            $uri = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid={$appid}&redirect_uri='.$uri.'&response_type=code&scope=snsapi_base#wechat_redirect';
            redirect($uri);
        }else{
            $res = $this->get_openid($appid,$secret,$code);
            if($res['errcode'] == "40003"){
                //  // 进入关注引导
                    return "未关注";
            }elseif($res['errcode']){
                $uri = getServerUri();
                $uri = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid={$appid}&redirect_uri='.$uri.'&response_type=code&scope=snsapi_base#wechat_redirect';
                redirect($uri);
            }else{
            	//获取用户信息
            	$res = $this->get_userinfo($access_token,$res['openid']);
                $res = json_decode($res,true);

                if($res['errcode']){
                    $uri = getServerUri();
                    $uri = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid='.C("WX_APPID").'&redirect_uri='.$uri.'&response_type=code&scope=snsapi_base#wechat_redirect';
                    redirect($uri);
                }elseif($res['subscribe'] != "1"){   //$res['subscribe'] == 1 是已关注  !=1 是未关注
                      // 进入关注引导
                    return "未关注";
                }else{

                    return $res; //获取的用户信息
                }
               
            }
        }
        
    }

	/** 创建菜单
	 * @param $access_token   //公众号的access_token
	 * @param $menuarr   //自定义菜单数组
	 *
	 * @return 成功时返回ok，其他抛异常（参数错误）
	 */
	// 注意1：如果使用安全连接 在menuarr 数组内填写的url前后要加上$uri1和uri2,如第一个按钮所示。反之则不加 如第三个按钮所示。其中$appid 是第三方用户唯一凭证请注意调换
	// 注意2：如说想做二级菜单就仿照第二个按钮的结构写。
	// 注意3：数组内键名不可更改，数组结构和键值根据自己的需求而定

	// $uri1 = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid='.$appid.'&redirect_uri=';
 //    $uri2 = '&response_type=code&scope=snsapi_base#wechat_redirect';
	// $menuarr = array(
 //            "button" => array(
 //                array(
 //                        "type" =>"view",
 //                        "name" => "第一个按钮",
 //                        "url" => $uri1 . "第一个按钮被点击后跳转的链接（从http://开始）" . $uri2,
 //                    ),
 //                array(
 //                    "name"=>"第二个按钮（含有两个子菜单）",
 //                    "sub_button" => array(
 //                        array(
 //                            "name" => "第一个子菜单",
 //                            "type"  => "view",
 //                            "url" => $uri1 . "第一个菜单被选择后跳转的链接（从http://开始）" . $uri2,
 //                            ),
 //                        array(
 //                            "name"=> "第二个子菜单",
 //                            "type"=>"view",
 //                            "url" => $uri1 . "第二个菜单被选择后跳转的链接（从http://开始）" . $uri2,
 //                            )
 //                        )
 //                    ),
 //                array(
 //                    "name"=>"第三个按钮",
 //                    "type"=>"view",
 //                    "url" => $uri1 . "第三个按钮被点击后跳转的链接（从http://开始）" . $uri2,
 //                    )
 //                )
 //            );
    
	public function creat_menu($menuarr,$access_token)
	{  
		//$menuarr的内容参考方法上面的注释
		$menuarr = json_encode($menuarr,JSON_UNESCAPED_UNICODE);
		$uri = "https://api.weixin.qq.com/cgi-bin/menu/create?access_token=".$access_token;
		$result = $this->curl_post($menuarr,$uri);
		return $result;
	}


	/**
	 * 
	 * 
	 * 
	 * @param 
	 * @param 
	 * @throws 
	 * @return 成功时返回，其他抛异常
	 */
	// public function text_img_respond($msgtype, $timeOut = 6)
	// {
	// 	$msg = $this->xml_to_object();
	// 	if($msg->MsgType == $msgtype){

	// 	}
	
		
	// }

	private function xml_to_object(){
		//禁止引用外部xml实体 
		libxml_disable_entity_loader(true); 
		$xmlstring = simplexml_load_string(file_get_contents("php://input"), 'SimpleXMLElement', LIBXML_NOCDATA);
		return json_decode(json_encode($xmlstring));
	}

	/**
	 * 获取签名  jsapi用   该方法用于控制分享 扫描二维码跟上传图片
	 * 页面控制的方法，获取签名的方法。
	 * 使用方法 前台引用sharecontro.html
	 * @param 
	 * @param 
	 * @throws 
	 * @return 成功时返回，其他抛异常
	 */
	public function get_jsapi($token,$url){

        $wxurl = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=".$token."&type=jsapi";
        $data = $this->curl_get($wxurl);
        $data = json_decode($data,true);
        $jsticket = $data['ticket'];
        $res['nonceStr'] = $this->nonceStr(8);
        $res['timestamp'] = time();
        $str = trim('jsapi_ticket='.$jsticket.'&noncestr='.$res['nonceStr']."&"."timestamp=".$res['timestamp']."&url="."http://".$_SERVER ['HTTP_HOST'].$_SERVER['REQUEST_URI']);
        
        $res['signature'] = sha1($str);
        if(!$url){
        	$url = U(MODULE_NAME."/".CONTROLLER_NAME."/".ACTION_NAME."@ticket.binxian58.com",array(),"html");
        }
        $res['defaultUrl'] = $url;
        
        return $res;//输出到前台  public 下的sharecontro可以用
    }

    //
    /**
	 * 图片上传和修改
	 * 
	 * 
	 * @param $imgid  是前台上传返回的图片id
	 * @param $access_token 公众号的access_token
	 * @param $name  图片名 随机数或者跟用户id绑定都可以
	 * @throws 
	 * @return 成功时返回，其他抛异常
	 */
    //页面的js

 //      function changealbum(){
 //        var images = {  
 //            localId: [],  
 //            serverId: []
 //        };  
 //        wx.chooseImage({  
 //            count: 1, // 默认9
 //            sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
 //            sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
 //            success: function(res) {  
 //                images.localId = res.localIds;
  
 //                if (images.localId.length == 0) {  
 //                    return;  
 //                }  
 //                var i = 0, length = images.localId.length;  
 //                images.serverId = [];  
 //                wx.uploadImage({  
 //                    localId: images.localId[i],
 //                    isShowProgressTips: 1, // 默认为1，显示进度提示
 //                    success: function(res) {
 //                        i++;
 //                        // wx_img(res.serverId); //将（res.serverId） 传给后台wx_img 方法 $imgid的位置
 //                        images.serverId.push(res.serverId);
 //                    },  
 //                    fail: function(res) {  
 //                        console.log(JSON.stringify(res));  
 //                    }  
 //                });   
 //            }  
 //        }); 
	// }
      public function wx_img($imgid,$access_token,$name){
        
        $targetName = "./Public/shopalbum/{$name}.jpg";
        $subname = "./Public/shopalbum/{$name}_100.jpg";
        $ch = curl_init("http://file.api.weixin.qq.com/cgi-bin/media/get?access_token={$access_token}&media_id={$imgid}");
        $fp = fopen($targetName, 'wb');
	        curl_setopt($ch, CURLOPT_FILE, $fp);
	        curl_setopt($ch, CURLOPT_HEADER, 0);
	        curl_exec($ch);
	        curl_close($ch);
	        fclose($fp);

        $image = new \Think\Image();
        $image->open($targetName);
        // 生成一个固定大小为150*150的缩略图并保存为thumb.jpg
        $image->thumb(100, 100,\Think\Image::IMAGE_THUMB_FIXED)->save($subname);

        $result['error'] = 1;
        $result['url'] = str_replace("./", "/", $subname);  //图片在服务器的路径
        return $result; 
    }
        //
    /**
	 * 扫描二维码
	 * 
	 * 
	 * @param $imgid  是前台上传返回的图片id
	 * @param $access_token 公众号的access_token
	 * @param $name  图片名 随机数或者跟用户id绑定都可以
	 * @throws 
	 * @return 成功时返回，其他抛异常
	 */

    //前台代码
  //   wx.scanQRCode({
		//     needResult: 1, // 默认为0，扫描结果由微信处理，1则直接返回扫描结果，
		//     scanType: ["qrCode","barCode"], // 可以指定扫二维码还是一维码，默认二者都有
		//     success: function (res) {
		//     	var result = res.resultStr;
        //后台走验票流程
		//     	setTimeout(function(){
    //后台走验票流程
		// 	    	$.ajax({
		// 	    		url:"{:U('Shop/Xticket/xres/param/"+result+"')}",
		// 	    		// dataType:"json",
		// 	    		success:function(res){
		// 	    			xcConfirm(res,"info",{onOk:function(){
		// 	    				location.href = location.href;  //验票成功返回结果 刷新当前页面
		// 	    			}});
		// 	    		}
		// 	    	})
		//     	},500)
		// 	}
		// });
  	//

    //支付方法
   	// 首先穿件订单  将返回的订单号传入callpay方法  如下格式
 //    function callpay(order)
	// {
	// 	$.ajax({
	// 	    url:"{:U('User/Shop/Weixinorderlist')}",        //跨域到http://www.wp.com，另，http://test.com也算跨域
	// 	    type:'POST',             //jsonp 类型下只能使用GET,不能用POST,这里不写默认为GET
	// 	    dataType:'json',                          //指定为jsonp类型
	// 	    data:{order:order},
	// 	    //jsonp:'callback',                          //服务器端获取回调函数名的key，对应后台有$_GET['callback']='getName';callback是默认值
	// 	    //jsonpCallback:'getNameapp',                   //回调函数名
	// 	    success:function(jsApiParameters){
	// 	    	console.log(jsApiParameters)
	// 	    	$(".a1").hide();

	// 			// if(res.error == 1){
	// 				// console.log(jsApiParameters);
	// 				if (typeof WeixinJSBridge == "undefined"){
	// 				    if( document.addEventListener ){
	// 				        document.addEventListener('WeixinJSBridgeReady', jsApiCall, false);
	// 				    }else if (document.attachEvent){
	// 				        document.attachEvent('WeixinJSBridgeReady', jsApiCall); 
	// 				        document.attachEvent('onWeixinJSBridgeReady', jsApiCall);
	// 				    }
	// 				}else{
	// 				    jsApiCall(jsApiParameters,order);
	// 				}

	// 	    }
	// 	});
	
	// }
	    /**
	 * 支付
	 *使用方法：首先在数据库里生成订单 然后调用 当前类的Weixin_order方法  将返回的参数返回到前台jsApiCall(jsApiParameters)里，最后在WxPay/PayNotifyCallBack.class.php  类的NotifyProcess方法中写下支付成功之后对该订单状态和金额的处理
	 * 
	 * 
	 * @param $money  订单金额 如果十一块钱则$money = 11.00
	 * @param $str 验证订单需要的一些数据  这里可以随意组合，例如： $orderinfo['id'] . "_" . $user['id'] . "_" . $user['openid'] . "_" . $money;  //
	 * @param $describe 设置商品或支付单简要描述   商家名称-销售商品类目   罗辑思维-图书
	 * @param $openId 设置商品或支付单简要描述   商家名称-销售商品类目   罗辑思维-图书
	 * @throws 
	 * @return 成功时返回 的 jsApiParameters传进jsApiCall方法里面，其他抛异常
	 */
/*前台代码开始*/
	//  function jsApiCall(jsApiParameters)
	// {
		//jsApiParameters 是从后台接口走下面Weixin_order()方法返回的参数
	// 	var jsapi = eval("("+jsApiParameters+")");
	// 	WeixinJSBridge.invoke(
	// 		'getBrandWCPayRequest',
	// 		jsapi,
	// 		function(res){
	// 			if(res.err_msg == "get_brand_wcpay_request:ok"){
	// 				// 支付成功
	// 				location.href = "{:U('User/Shop/index/pageact/1')}";
	// 			}else if(res.err_msg == "get_brand_wcpay_request:cancel"){
	// 				// 支付取消
	// 				cancelpay(orderid);
	// 			}else if(res.err_msg == "get_brand_wcpay_request:fail"){
	// 				// 支付失败
	// 				location.href = "{:U('User/Shop/index/pageact/1')}";
	// 			}
	// 		}
			
	// 	);
	// }
	//  function  cancelpay(orderid){
	// 	$.ajax({
	// 	    url:"{:U('User/Shop/cancelpay')}",        //跨域到http://www.wp.com，另，http://test.com也算跨域
	// 	    type:'POST',             //jsonp 类型下只能使用GET,不能用POST,这里不写默认为GET
	// 	    dataType:'json',                          //指定为jsonp类型
	// 	    data:{orderid:orderid},
	// 	    //jsonp:'callback',                          //服务器端获取回调函数名的key，对应后台有$_GET['callback']='getName';callback是默认值
	// 	    //jsonpCallback:'getNameapp',                   //回调函数名
	// 	    success:function(act){
	// 	    	if(act == 1){
	// 	    		location.href = "{:U('User/Shop/index/pageact/1')}";
	// 	    	}
	// 	    }
	// 	});
	// }
/*前台代码结束*/
	  /*注意：在WxPay/PayNotifyCallBack.class.php  类的NotifyProcess方法标记位置写上支付成功之后的后台订单金额的处理,其中该方法里$data的attach参数是Wxapi类（当前类）里面Weixin_order方法传进来的$str字符串，根据这个$str字符串也就是这个$data[attach'] 去核对订单信息和处理数据*/
	public function Weixin_order($money,$str,$describe,$openId){

		$money = $money * 100;
        import("Org.wx.WxPay.AutoRequire");

        //初始化日志
        $logHandler= new \CLogFileHandler("./logs/pay.log");
        
        $log = \Log::Init($logHandler, 15);
 
        $tools = new \JsApiPay();

        //②、统一下单
        $input = new \WxPayUnifiedOrder();
        $input->SetBody($describe);    // 设置商品或支付单简要描述   商家名称-销售商品类目   罗辑思维-图书
        $input->SetAttach($str);  // 设置附加数据，在查询API和支付通知中原样返回，该字段主要用于商户携带订单的自定义数据 string
        $input->SetOut_trade_no(\WxPayConfig::MCHID.date("YmdHis"));    // 设置商户系统内部的订单号,32个字符内、可包含字母, 其他说明见商户订单号
        $input->SetTotal_fee($money);  // 设置订单总金额，只能为整数，详见支付金额  单位为分
        $input->SetTime_start(date("YmdHis")); // 设置订单生成时间，格式为yyyyMMddHHmmss，如2009年12月25日9点10分10秒表示为20091225091010。其他详见时间规则
        $input->SetTime_expire(date("YmdHis", time() + 600));   // 设置订单失效时间，格式为yyyyMMddHHmmss，如2009年12月27日9点10分10秒表示为20091227091010。其他详见时间规则 
        $input->SetGoods_tag("test");   // 设置商品标记，代金券或立减优惠功能的参数，说明详见代金券或立减优惠
        $input->SetNotify_url("http://ticket.binxian58.com/index.php/Home/Index/notify.html");    // 设置接收微信支付异步通知回调地址  非必填  不填使用config中的回调
        $input->SetTrade_type("JSAPI"); // 模式选择 设置取值如下：JSAPI，NATIVE，APP，详细说明见参数规定
        $input->SetOpenid($openId); // 设置trade_type=JSAPI，此参数必传，用户在商户appid下的唯一标识。下单前需要调用【网页授权获取用户信息】接口获取到用户的Openid。 
        
        $order = \WxPayApi::unifiedOrder($input);

        //echo '<font color="#f00"><b>统一下单支付单信息</b></font><br/>';
        // printf_info($order);
        $jsApiParameters = $tools->GetJsApiParameters($order);

        //获取共享收货地址js函数参数
        // $editAddress = $tools->GetEditAddressParameters();
        return $jsApiParameters;
	}



	//获取随机数
    public function nonceStr($len){
        $chars = array( 
            "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k",  
            "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v",  
            "w", "x", "y", "z", "0", "1", "2", "3", "4", "5", "6", 
            "7", "8", "9"
        ); 
        $charsLen = count($chars) - 1; 
        shuffle($chars);   
        $output = ""; 
        for ($i=0; $i<$len; $i++) 
        { 
            $output .= $chars[mt_rand(0, $charsLen)]; 
        }
        return $output; 
    }


    //获取当前的uri
    public function getServerUri(){
        $uri = "http://".$_SERVER['HTTP_HOST'].$_SERVER['SCRIPT_NAME'];
        $uri .= "/" . MODULE_NAME . "/" . CONTROLLER_NAME  . "/" . ACTION_NAME ;
        $get = I("get.");
        unset($get['code'],$get['state'],$get['winzoom']);
        foreach($get as $k => $v){
            $uri .= "/".$k."/".$v;
        }
        $uri .= ".html";
        return $uri;
    }

	
	
}

